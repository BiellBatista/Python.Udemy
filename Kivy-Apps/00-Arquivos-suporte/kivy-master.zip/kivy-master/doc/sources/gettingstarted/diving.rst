Diving in
---------

To get straight into kivy, take a look at :doc:`/index`.

Kivy comes with a set of :doc:`examples` in the ``kivy_installation/examples``
directory. You should try modifying/improving/adapting them to your needs.

Browse our `wiki <https://github.com/kivy/kivy/wiki>`_ for info on related
projects, tutorials and snippets.

Understand the basics about :mod:`kivy graphics <kivy.graphics>`.

Take a look at the built-in :mod:`widgets <kivy.uix>`.

Follow the :doc:`/guide-index` to get even more familiar with kivy.

See how to use different :mod:`Modules <kivy.modules>` in the modules section,
such as the :mod:`Inspector <kivy.modules.inspector>` for live inspection.

Learn how to handle custom :mod:`Input <kivy.input>`.

See how kivy has been extended with :mod:`extensions <kivy.ext>` support.

Familiarize yourself with the :mod:`kivy framework <kivy>`.

Kivy is open source, so you can **contribute**. Take a look at the
:doc:`/contribute` section for guidelines.
